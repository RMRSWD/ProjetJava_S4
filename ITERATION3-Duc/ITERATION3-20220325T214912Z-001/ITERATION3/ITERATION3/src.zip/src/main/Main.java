package main;

import Interface.*;
import Nim.vue.Ihm;

public class Main {

    public static void main(String[] args) {
        IhmPrincipale ihm = new IhmPrincipale(Ihm);
        Controleur controleurJeuNim = new Controleur(ihm);
        controleurJeuNim.jouer();
    }
}
