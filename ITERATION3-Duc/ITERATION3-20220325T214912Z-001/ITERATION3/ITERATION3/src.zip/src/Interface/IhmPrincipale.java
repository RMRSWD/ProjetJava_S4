package Interface;

public interface IhmPrincipale {
    public void demanderNomJoueur();
    public void  afficherBarre();
    public  void re_jouer();
    public void scoreFinal();
}
