package Interface;

public interface Controleur {
    public abstract String barreInitiale();
    public abstract void nom_joueur(String o, String o1);
    public abstract   void changerTourJoueur();
    public abstract   void jouer();
    public abstract void versionContinuer();

}
