package Interface;

public interface Joueur {
 public void tourDeRole();
 public void gagnePartie();
}
