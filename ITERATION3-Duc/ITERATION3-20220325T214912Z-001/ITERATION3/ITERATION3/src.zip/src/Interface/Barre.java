package Interface;

public interface Barre {
    public abstract void initialiser();
    public abstract void partieTerminer();
}
