package coup;

public class Coup  {





    public void gererCoup(Coup coup){}

}
