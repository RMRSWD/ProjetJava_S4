package vue;
import java.util.*;

import controleur.ControleurJeuNim;
import modele.*;

public class Ihm {
    private ControleurJeuNim controleurJeuNim;

    public Ihm() {
        System.out.println(" Bienvenue dans le jeu de Nim. Vous pouvez commencez");
    }

    public void setControleurJeuNim(ControleurJeuNim controleurJeuNim){
        this.controleurJeuNim=controleurJeuNim;
    }


    public void saisie_nbre_tas() {
        System.out.println("Veuillez saisir le nombre de tas :");
        Scanner sc = new Scanner(System.in);
        int nbre_tas = -1;
        do {
            if (sc.hasNextInt()) {

                nbre_tas = sc.nextInt();
                if (nbre_tas >= 1) {
                    controleurJeuNim.gerer_nbTas(nbre_tas);

                }
                else{
                    System.out.println("Veuillez saisir un entier strictement supérieur à zéro");
                }
            }
            else{
                System.out.println("Veillez saisir une valeur entière");
                sc.next();
            }
        } while ((nbre_tas <= 0));
    }

    public void demanderNomJoueur(){
        Scanner sc = new Scanner (System.in);
            System.out.println("Entrer le nom du joueur premier joueur");
            String nomJoueur1 = sc.nextLine();
            System.out.println("Entrer le nom du deuxième joueur  : ");
            String nomJoueur2=sc.nextLine();
            controleurJeuNim.nom_joueur(nomJoueur1,nomJoueur2);

    }


//permet l'affichage des tas qui a été donner par le controleur
    public void afficherTas() {
        System.out.println(controleurJeuNim.TasInitial());
    }

    public void demanderCoup(Joueur j) {

        int numTas = 0;
        int nbMaxAllumettes = 0;
        boolean condition = false;
        do {
            System.out.println(j.getNom() + " a vous de jouer : ");
            Scanner sc = new Scanner(System.in);

            if (sc.hasNextInt()) {
                numTas = sc.nextInt();
                nbMaxAllumettes = sc.nextInt();
                if (numTas > 0 && nbMaxAllumettes > 0) {
                    controleurJeuNim.recupererCoup(numTas, nbMaxAllumettes);
                    break;
                } else {
                    System.out.println(j.getNom() + "Entrez des valeurs positives !! ");
                    condition = true;
                }
            } else {
                System.out.println(" Veillez saisir un coup  valide");
                condition = true;
            }


        } while (condition);
    }


    public void afficherGagnant(Joueur gagnant){
        System.out.println("Le joueur "+ gagnant.getNom() + " a gagné !");
        System.out.println("Nombre de partie gagné "+ gagnant.getNbPartiesGagnees());
        System.out.println(" ");
    }

    public void replay(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Voulez-vous rejouer ? (o/n) : ");
        String answer;
        boolean condition;
        do {


            if(sc.hasNext()){

                answer = sc.next();
                if(answer.equals("oui")){
                    controleurJeuNim.gererReponseReplay(answer);
                    break;
                }else if (answer.equals("non")){
                    controleurJeuNim.gererReponseReplay(answer);
                    condition = false;
                }else{
                    System.out.println("Veuillez entrer une réponse valide");
                    condition = true;
                }
            }
            else{
                System.out.println("Veuillez entrer une réponse valide");
                condition = true;
            }

        }while(condition); // !condition => condition == false // condition => condition == true


    }


}



